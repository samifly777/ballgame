﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Hack_Peel
{
    public partial class Form1 : Form
    {
        int Mode; // 1 = easy, 2 = medium, 3 = hard
        int Lives = 3; //1,2,3 or 0
        public int[,] BrickArray = new int[14, 11]; //14 blocks vertically x 11 blocks horizonatally 

        //offset: Global Variable
        int x = 2;  //??
        int y = -2; //??

        public Form1()
        {
            InitializeComponent();
            rbEasy.Checked = true;
            Lives = 3; // start out with three lives


            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);

            //fills array with 0 for empty (1 = almost broken, 2 = full brick)
            for (int i = 0; x < 14; x++)
            {
                for (int j = 0; y < 11; y++)
                {
                    BrickArray[i, j] = 0;
                }
            }

        }

        private void rbEasy_CheckedChanged(object sender, EventArgs e)
        {
            Mode = 1;
        }

        private void rbMedium_CheckedChanged(object sender, EventArgs e)
        {
            Mode = 2;
        }

        private void rbHard_CheckedChanged(object sender, EventArgs e)
        {
            Mode = 3;
        }

        private void btnplay_Click(object sender, EventArgs e)
        {
            BallBounceTimer.Enabled = true;

            // pbHeart1.Image;
        }

        // timer for ball movement
        // the picturebox for the ball is: 30x30
        private void BallBounceTimer_Tick(object sender, EventArgs e)
        {

            pbBall.Top = pbBall.Top + y;
            pbBall.Left = pbBall.Left + x;

            //Bounce from moving space bar
            if (pbBall.Bottom >= pbPEZ.Top
                && pbBall.Left >= pbPEZ.Left
                && pbBall.Right <= pbPEZ.Right)
            {
                pbBall.Top = pbPEZ.Top - pbBall.Height;
                y = -y;
            }



            //bounce from bottom wall
            if (pbBall.Bottom >= pbBoundaries.Bottom)
            {

                if (Lives == 3)
                {
                    Lives--;
                    pbHeart3.BackgroundImage = Image.FromFile("BROKENHEART.png");

                    //Sets Location
                    pbBall.Top = pbBoundaries.Bottom - pbBall.Height;
                    //Changes Direction
                    y = -y;
                }
                else if (Lives == 2)
                {
                    Lives--;
                    pbHeart2.BackgroundImage = Image.FromFile("BROKENHEART.png");
                }
                else
                {
                    pbHeart1.BackgroundImage = Image.FromFile("BROKENHEART.png");
                    BallBounceTimer.Stop();

                    MessageBox.Show("Game Over");
                    
                }
               
                
            }

            //Bounce from the top wall
            if (pbBall.Top <= pbBoundaries.Top)
            {
                //Sets Location
                pbBall.Top = pbBoundaries.Top;
                //Changes Direction
                y = -y;
            }

            //Bounce from the Left Wall
            if (pbBall.Left <= pbBoundaries.Left)
            {
                //Sets Location
                pbBall.Left = pbBoundaries.Left;
                //Changes direction
                x = -x;
            }

            //Bounce from the Right Wall
            if (pbBall.Right >= pbBoundaries.Right)
            {
                //Sets Location
                pbBall.Left = pbBoundaries.Right - pbBall.Width;
                //Changes direction
                x = -x;
            }


            //Refresh the Ball PictureBox
            pbBall.Refresh();

        }

        //Game box = 770 x 350 // 14 blocks vertically x 11 blocks horizontally

        //every interval or so, this timer will check if any of the keys on the keyboard has been pressed
        //and moves the bar accordingly
        private void BarTimer_Tick(object sender, EventArgs e)
        {


        }


        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
                pbPEZ.Left = pbPEZ.Left + 4;

            if (e.KeyCode == Keys.Right)
                pbPEZ.Left = pbPEZ.Left - 4;
          

            /*
            if (e.KeyCode == Keys.A)
            {
                //Moves image ot the left
                A = A - 10;
                pbPEZ.Location = new Point(A, B);
            }

            else if (e.KeyCode == Keys.D)
            {
                A = A + 10;
                pbPEZ.Location = new Point(A, B);
            }
            */

        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Left) pbPEZ.Left = pbPEZ.Left - 4;
            if (keyData == Keys.Right) pbPEZ.Left = pbPEZ.Left + 4;
            return base.ProcessCmdKey(ref msg, keyData);
        }

    }
}
