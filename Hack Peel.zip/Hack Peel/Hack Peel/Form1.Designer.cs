﻿
namespace Hack_Peel
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.rbEasy = new System.Windows.Forms.RadioButton();
            this.rbMedium = new System.Windows.Forms.RadioButton();
            this.rbHard = new System.Windows.Forms.RadioButton();
            this.btnPlay = new System.Windows.Forms.Button();
            this.btnResume = new System.Windows.Forms.Button();
            this.btnPause = new System.Windows.Forms.Button();
            this.btnRestart = new System.Windows.Forms.Button();
            this.BallBounceTimer = new System.Windows.Forms.Timer(this.components);
            this.btnPasue = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.BarTimer = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.pbPEZ = new System.Windows.Forms.PictureBox();
            this.pbInfo = new System.Windows.Forms.PictureBox();
            this.pbBall = new System.Windows.Forms.PictureBox();
            this.pbHeart3 = new System.Windows.Forms.PictureBox();
            this.pbHeart2 = new System.Windows.Forms.PictureBox();
            this.pbHeart1 = new System.Windows.Forms.PictureBox();
            this.pbBrick = new System.Windows.Forms.PictureBox();
            this.pbBoundaries = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbPEZ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBall)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHeart3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHeart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHeart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBrick)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBoundaries)).BeginInit();
            this.SuspendLayout();
            // 
            // rbEasy
            // 
            this.rbEasy.AutoSize = true;
            this.rbEasy.Font = new System.Drawing.Font("Rockwell", 8F);
            this.rbEasy.Location = new System.Drawing.Point(12, 56);
            this.rbEasy.Name = "rbEasy";
            this.rbEasy.Size = new System.Drawing.Size(48, 17);
            this.rbEasy.TabIndex = 1;
            this.rbEasy.TabStop = true;
            this.rbEasy.Text = "easy";
            this.rbEasy.UseVisualStyleBackColor = true;
            this.rbEasy.CheckedChanged += new System.EventHandler(this.rbEasy_CheckedChanged);
            // 
            // rbMedium
            // 
            this.rbMedium.AutoSize = true;
            this.rbMedium.Font = new System.Drawing.Font("Rockwell", 8F);
            this.rbMedium.Location = new System.Drawing.Point(12, 79);
            this.rbMedium.Name = "rbMedium";
            this.rbMedium.Size = new System.Drawing.Size(67, 17);
            this.rbMedium.TabIndex = 2;
            this.rbMedium.TabStop = true;
            this.rbMedium.Text = "medium";
            this.rbMedium.UseVisualStyleBackColor = true;
            this.rbMedium.CheckedChanged += new System.EventHandler(this.rbMedium_CheckedChanged);
            // 
            // rbHard
            // 
            this.rbHard.AutoSize = true;
            this.rbHard.Font = new System.Drawing.Font("Rockwell", 8F);
            this.rbHard.Location = new System.Drawing.Point(12, 102);
            this.rbHard.Name = "rbHard";
            this.rbHard.Size = new System.Drawing.Size(49, 17);
            this.rbHard.TabIndex = 3;
            this.rbHard.TabStop = true;
            this.rbHard.Text = "hard";
            this.rbHard.UseVisualStyleBackColor = true;
            this.rbHard.CheckedChanged += new System.EventHandler(this.rbHard_CheckedChanged);
            // 
            // btnPlay
            // 
            this.btnPlay.Font = new System.Drawing.Font("Rockwell", 8F);
            this.btnPlay.Location = new System.Drawing.Point(12, 139);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(75, 23);
            this.btnPlay.TabIndex = 4;
            this.btnPlay.Text = "play";
            this.btnPlay.UseVisualStyleBackColor = true;
            this.btnPlay.Click += new System.EventHandler(this.btnplay_Click);
            // 
            // btnResume
            // 
            this.btnResume.Font = new System.Drawing.Font("Rockwell", 8F);
            this.btnResume.Location = new System.Drawing.Point(12, 197);
            this.btnResume.Name = "btnResume";
            this.btnResume.Size = new System.Drawing.Size(75, 23);
            this.btnResume.TabIndex = 5;
            this.btnResume.Text = "resume";
            this.btnResume.UseVisualStyleBackColor = true;
            // 
            // btnPause
            // 
            this.btnPause.Font = new System.Drawing.Font("Rockwell", 8F);
            this.btnPause.Location = new System.Drawing.Point(12, 226);
            this.btnPause.Name = "btnPause";
            this.btnPause.Size = new System.Drawing.Size(75, 23);
            this.btnPause.TabIndex = 6;
            this.btnPause.Text = "Pause";
            this.btnPause.UseVisualStyleBackColor = true;
            // 
            // btnRestart
            // 
            this.btnRestart.Font = new System.Drawing.Font("Rockwell", 8F);
            this.btnRestart.Location = new System.Drawing.Point(12, 226);
            this.btnRestart.Name = "btnRestart";
            this.btnRestart.Size = new System.Drawing.Size(75, 23);
            this.btnRestart.TabIndex = 7;
            this.btnRestart.Text = "restart";
            this.btnRestart.UseVisualStyleBackColor = true;
            // 
            // BallBounceTimer
            // 
            this.BallBounceTimer.Tick += new System.EventHandler(this.BallBounceTimer_Tick);
            // 
            // btnPasue
            // 
            this.btnPasue.Font = new System.Drawing.Font("Rockwell", 8F);
            this.btnPasue.Location = new System.Drawing.Point(12, 168);
            this.btnPasue.Name = "btnPasue";
            this.btnPasue.Size = new System.Drawing.Size(75, 23);
            this.btnPasue.TabIndex = 14;
            this.btnPasue.Text = "pause";
            this.btnPasue.UseVisualStyleBackColor = true;
            // 
            // BarTimer
            // 
            this.BarTimer.Tick += new System.EventHandler(this.BarTimer_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Rockwell", 20F);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label1.Location = new System.Drawing.Point(8, 12);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(166, 31);
            this.label1.TabIndex = 17;
            this.label1.Text = "BALL GAME";
            // 
            // pbPEZ
            // 
            this.pbPEZ.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbPEZ.Image = ((System.Drawing.Image)(resources.GetObject("pbPEZ.Image")));
            this.pbPEZ.Location = new System.Drawing.Point(453, 363);
            this.pbPEZ.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pbPEZ.Name = "pbPEZ";
            this.pbPEZ.Size = new System.Drawing.Size(107, 36);
            this.pbPEZ.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbPEZ.TabIndex = 16;
            this.pbPEZ.TabStop = false;
            // 
            // pbInfo
            // 
            this.pbInfo.BackgroundImage = global::Hack_Peel.Properties.Resources.INFO_ICON;
            this.pbInfo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbInfo.Location = new System.Drawing.Point(49, 330);
            this.pbInfo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pbInfo.Name = "pbInfo";
            this.pbInfo.Size = new System.Drawing.Size(23, 23);
            this.pbInfo.TabIndex = 15;
            this.pbInfo.TabStop = false;
            // 
            // pbBall
            // 
            this.pbBall.BackgroundImage = global::Hack_Peel.Properties.Resources.BALL;
            this.pbBall.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbBall.Location = new System.Drawing.Point(488, 342);
            this.pbBall.Name = "pbBall";
            this.pbBall.Size = new System.Drawing.Size(20, 20);
            this.pbBall.TabIndex = 13;
            this.pbBall.TabStop = false;
            // 
            // pbHeart3
            // 
            this.pbHeart3.BackgroundImage = global::Hack_Peel.Properties.Resources.HEART;
            this.pbHeart3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbHeart3.Location = new System.Drawing.Point(796, 12);
            this.pbHeart3.Name = "pbHeart3";
            this.pbHeart3.Size = new System.Drawing.Size(35, 30);
            this.pbHeart3.TabIndex = 12;
            this.pbHeart3.TabStop = false;
            // 
            // pbHeart2
            // 
            this.pbHeart2.BackgroundImage = global::Hack_Peel.Properties.Resources.HEART;
            this.pbHeart2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbHeart2.Location = new System.Drawing.Point(838, 12);
            this.pbHeart2.Name = "pbHeart2";
            this.pbHeart2.Size = new System.Drawing.Size(35, 30);
            this.pbHeart2.TabIndex = 11;
            this.pbHeart2.TabStop = false;
            // 
            // pbHeart1
            // 
            this.pbHeart1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbHeart1.BackgroundImage")));
            this.pbHeart1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbHeart1.Location = new System.Drawing.Point(756, 12);
            this.pbHeart1.Name = "pbHeart1";
            this.pbHeart1.Size = new System.Drawing.Size(35, 30);
            this.pbHeart1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbHeart1.TabIndex = 10;
            this.pbHeart1.TabStop = false;
            // 
            // pbBrick
            // 
            this.pbBrick.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbBrick.BackgroundImage")));
            this.pbBrick.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbBrick.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbBrick.InitialImage")));
            this.pbBrick.Location = new System.Drawing.Point(400, 180);
            this.pbBrick.Name = "pbBrick";
            this.pbBrick.Size = new System.Drawing.Size(70, 25);
            this.pbBrick.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbBrick.TabIndex = 9;
            this.pbBrick.TabStop = false;
            // 
            // pbBoundaries
            // 
            this.pbBoundaries.BackColor = System.Drawing.Color.RoyalBlue;
            this.pbBoundaries.BackgroundImage = global::Hack_Peel.Properties.Resources.GREY_BG;
            this.pbBoundaries.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbBoundaries.Location = new System.Drawing.Point(103, 56);
            this.pbBoundaries.Name = "pbBoundaries";
            this.pbBoundaries.Size = new System.Drawing.Size(770, 350);
            this.pbBoundaries.TabIndex = 0;
            this.pbBoundaries.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(856, 402);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pbPEZ);
            this.Controls.Add(this.pbInfo);
            this.Controls.Add(this.btnPasue);
            this.Controls.Add(this.pbBall);
            this.Controls.Add(this.pbHeart3);
            this.Controls.Add(this.pbHeart2);
            this.Controls.Add(this.pbHeart1);
            this.Controls.Add(this.pbBrick);
            this.Controls.Add(this.btnRestart);
            this.Controls.Add(this.btnPause);
            this.Controls.Add(this.btnResume);
            this.Controls.Add(this.btnPlay);
            this.Controls.Add(this.rbHard);
            this.Controls.Add(this.rbMedium);
            this.Controls.Add(this.rbEasy);
            this.Controls.Add(this.pbBoundaries);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "BALLS";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.pbPEZ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBall)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHeart3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHeart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHeart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBrick)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBoundaries)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbBoundaries;
        private System.Windows.Forms.RadioButton rbEasy;
        private System.Windows.Forms.RadioButton rbMedium;
        private System.Windows.Forms.RadioButton rbHard;
        private System.Windows.Forms.Button btnPlay;
        private System.Windows.Forms.Button btnResume;
        private System.Windows.Forms.Button btnPause;
        private System.Windows.Forms.Button btnRestart;
        private System.Windows.Forms.Timer BallBounceTimer;
        private System.Windows.Forms.PictureBox pbBrick;
        private System.Windows.Forms.PictureBox pbHeart1;
        private System.Windows.Forms.PictureBox pbHeart2;
        private System.Windows.Forms.PictureBox pbHeart3;
        private System.Windows.Forms.PictureBox pbBall;
        private System.Windows.Forms.Button btnPasue;
        private System.Windows.Forms.PictureBox pbInfo;
        private System.Windows.Forms.PictureBox pbPEZ;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Timer BarTimer;
        private System.Windows.Forms.Label label1;
    }
}

